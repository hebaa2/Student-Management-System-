import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class MainGUI {
    // Database connection details
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/selected";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "822004";

    public static void main(String[] args) {
       // try {
            // Load PostgreSQL driver
           // Class.forName("org.postgresql.Driver");
       // } catch (ClassNotFoundException e) {
         //   JOptionPane.showMessageDialog(null, "Driver not found: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
         //   return;
      //  }

        JFrame frame = new JFrame("Student and Course Management");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1, 10, 10));

        JButton studentButton = new JButton("Manage Students");
        JButton courseButton = new JButton("Manage Courses");
        JButton enrollmentButton = new JButton("Enroll Students");
        JButton finalGradeButton = new JButton("Total Grade");

        panel.add(studentButton);
        panel.add(courseButton);
        panel.add(enrollmentButton);
        panel.add(finalGradeButton);

        frame.add(panel);

        studentButton.addActionListener(e -> manageStudents(frame));
        courseButton.addActionListener(e -> manageCourses(frame));
        enrollmentButton.addActionListener(e -> enrollStudents(frame));
        finalGradeButton.addActionListener(e -> calculateFinalGrade(frame));

        frame.setVisible(true);
    }

    private static void manageStudents(JFrame frame) {
        String studentName = JOptionPane.showInputDialog(frame, "Enter Student Name:");
        String studentType = JOptionPane.showInputDialog(frame, "Enter Student Type (Graduate, Undergraduate, Part-Time):");

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO Students (student_name, student_type) VALUES (?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, studentName);
            pstmt.setString(2, studentType);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(frame, "Student added successfully!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void manageCourses(JFrame frame) {
        String courseName = JOptionPane.showInputDialog(frame, "Enter Course Name:");
        String courseType = JOptionPane.showInputDialog(frame, "Enter Course Type (Core, Elective, Lab):");

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO Courses (name, type) VALUES (?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, courseName);
            pstmt.setString(2, courseType);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(frame, "Course added successfully!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void enrollStudents(JFrame frame) {
        String studentId = JOptionPane.showInputDialog(frame, "Enter Student ID:");
        String courseId = JOptionPane.showInputDialog(frame, "Enter Course ID:");

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO Enrollments (student_id, courses) VALUES (?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, Integer.parseInt(studentId));
            pstmt.setInt(2, Integer.parseInt(courseId));
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(frame, "Enrollment successful!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void calculateFinalGrade(JFrame frame) {
        String studentId = JOptionPane.showInputDialog(frame, "Enter Student ID:");
        double totalWeight = 0;
        double weightedSum = 0;

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT c.weight, e.grade FROM Enrollments e JOIN Courses c ON e.courses= c.id WHERE e.student_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, Integer.parseInt(studentId));
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int weight = rs.getInt("weight");
                int grade = rs.getInt("grade");
                weightedSum += grade * weight;
                totalWeight += weight;
            }

            double finalGrade = totalWeight == 0 ? 0 : weightedSum / totalWeight;
            JOptionPane.showMessageDialog(frame, "The total grade is: " + finalGrade);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}