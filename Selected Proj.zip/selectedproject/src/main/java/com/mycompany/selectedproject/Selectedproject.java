/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.selectedproject;

/**
 *
 * @author Al-Ahram
 */
import java.util.*;
import java.util.HashMap;
import java.util.Map;

public class Selectedproject {
                                     //public class studenttype (factory design)
    public interface StudentTypes {
        void Type();
    }

    // Graduate class implementing StudentTypes
    public static class Graduate implements StudentTypes {
        @Override
        public void Type() {
            System.out.println("id = 2100719" +"," +  "Student type : Graduate");
        }
    }

   
    public static class Undergraduate implements StudentTypes {
        @Override
        public void Type() {
            System.out.println("id = 21000"   +","+   "Student type : Undergraduate");
        }
    }

   
    public static class PartTime implements StudentTypes {
        @Override
        public void Type() {
            System.out.println("id = 21001"    +","+   "Student type : Part-Time");
        }
    }

    
    public static class StudentTypesFactory {
        public static StudentTypes createStudent(String type) {
            if (type == null || type.isEmpty()) {
                throw new IllegalArgumentException("Student type cannot be null or empty.");
            }
            switch (type) {
                case "Graduate":
                    return new Graduate();
                case "Undergraduate":
                    return new Undergraduate();
                case "Part-Time":
                    return new PartTime();
                default:
                    throw new IllegalArgumentException("Unknown student type: " + type);
            }
        }
    }
                                        //public class coursetype (factory design) {
     public interface CourseTypes {
        void displayType();
    }

  
    public static class Course1 implements CourseTypes {
        @Override
        public void displayType() {
            System.out.println("Core course: Math");
        }
    }

    public static class Course2 implements CourseTypes {
        @Override
        public void displayType() {
            System.out.println("Elective course  : History");
        }
    }


    public static class Course3 implements CourseTypes {
        @Override
        public void displayType() {
            System.out.println("Lab course :physics");
        }
    }

  
    public static class CourseTypesFactory {
        public static CourseTypes createCourse(String type) {
            if (type == null || type.isEmpty()) {
                throw new IllegalArgumentException("Student type cannot be null or empty.");
            }
            switch (type) {
                case "Core":
                    return new Course1();
                case "Elective":
                    return new Course2();
                case "Lab":
                    return new Course3();
                default:
                    throw new IllegalArgumentException("Unknown student type: " + type);
            }
        }
    }
                                          //public class CourseRegistration (singlton design)
      public static class CourseRegistration {
  // Create a referance from same class (private static)
  private static CourseRegistration oneinstance;
  // Create method to get instance
  public static CourseRegistration getinstance(){
      if(oneinstance == null){
          oneinstance = new CourseRegistration();
      }
      return oneinstance;
  }

        public static CourseRegistration getInstance() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public static List<String> getCoursesForStudent(String studentId) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
  // make data to track enrollments(student id --> set of courses)
  private final Map<String,Set<String>> enrollments;
  //
  private CourseRegistration(){
      enrollments =new HashMap<>();
  } 
  //method to enroll student in course
  public void enroll(String StudentId, String CourseName){
      enrollments.putIfAbsent(StudentId, new HashSet<>());
      enrollments.get(StudentId).add(CourseName);
  }
  // method to display all enrollments
  public void printEnrollments(){
      enrollments.forEach((StudentId,CourseName)->{System.out.println("student ID : "+StudentId +" ,Courses :  "+CourseName);});
  }
    } 
                                                // singleton design 2
      public static class GradeProcessing {
    // Static reference to the single instance of the class
    private static GradeProcessing instance;
    
    // Grade weights storage
    private Map<String, Integer> gradeWeights;

    // Private constructor to prevent instantiation
    private GradeProcessing() {
        gradeWeights = new HashMap<>();
    }
  // Public method to provide access to the instance (Thread-safe)
    public static synchronized GradeProcessing getInstance() {
        if (instance == null) {
            instance = new GradeProcessing();
        }
        return instance;
    }
       // Set weight for a specific subject
    public void setGradeWeight(String subject, int weight) {
        gradeWeights.put(subject, weight);
    }

    // Calculate the weighted average grade
    public double calculateGrade(Map<String, Integer> grades) {
        double totalWeight = 0;
        double weightedSum = 0;

        for (Map.Entry<String, Integer> entry : grades.entrySet()) {
            String subject = entry.getKey();   // Get the subject name (key of the map)
            int grade = entry.getValue();
            int weight = gradeWeights.getOrDefault(subject, 1);  // Default weight is 1 if not set
            weightedSum += grade * weight;
            totalWeight += weight;
        }
        // shorthand for a simple if-else statement. It is used to check if totalWeight is zero
        //and if so, returns 0. Otherwise, it performs the calculation weightedSum / totalWeight and returns the result.
        return totalWeight == 0 ? 0 : weightedSum / totalWeight;
    }
}
                                                // builder design pattern

// Class representing a Student
public static class Students_ {
    private String name;
    private int id;
    private List<String> courses;

    private Students_(String name, int id, List<String> courses) {
        this.name = name;
        this.id = id;
        this.courses = courses;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", id=" + id +
                ", courses=" + courses +
                '}';
    }

    // Static Builder Class
    public static class StudentBuilder {
        private String name;
        private int id;
        private List<String> courses = new ArrayList<>();

        public  StudentBuilder(String name, int id) {
            this.name = name;
            this.id = id;
        }

        public StudentBuilder addCourse(String course) {
            this.courses.add(course);
            return this;
        }

        public Students_ build() {
            return new Students_(name, id, courses);
        }
    }
}
                                          // prototype design pattern
   public interface Course_ {
    Course_ clone();
    void displayInfo();
}
    // Represents a core course
public static class CoreCourse implements Course_ {
    private String name; // The name of the course

    // Constructor to initialize the course name
    public CoreCourse(String name) {
        this.name = name;
    }

    // Implements the clone method to create a copy of the course
    @Override
    public Course_ clone() {
        return new CoreCourse(this.name); // Returns a new CoreCourse object
    }

    // Displays information about the core course
    @Override
    public void displayInfo() {
        System.out.println("Core Course: " + name);
    }
}

// Represents an elective course
public static class ElectiveCourse implements Course_ {
    private String name; // The name of the course

    // Constructor to initialize the course name
    public ElectiveCourse(String name) {
        this.name = name;
    }

    // Implements the clone method to create a copy of the course
    @Override
    public Course_ clone() {
        return new ElectiveCourse(this.name); // Returns a new ElectiveCourse object
    }

    // Displays information about the elective course
    @Override
    public void displayInfo() {
        System.out.println("Elective Course: " + name);
    }
}

// Represents a lab course
public static class LabCourse implements Course_ {
    private String name; // The name of the course

    // Constructor to initialize the course name
    public LabCourse(String name) {
        this.name = name;
    }

    // Implements the clone method to create a copy of the course
       @Override
    public Course_ clone() {
        return new LabCourse(this.name); // Returns a new LabCourse object
    }

    // Displays information about the lab course
      @Override
    public void displayInfo() {
        System.out.println("Lab Course: " + name);
    }
}

                                                           // proxy
// Interface representing a Course
public  interface _Course {
    // Method to display course details
    void Info();
}
// Represents a core course
public static class CoreCourse_ implements _Course {
    
    private String name;

    // Constructor to initialize the course name
    public CoreCourse_(String name) {
        this.name = name;
    }

    // Displays course details
    @Override
    public void Info() {
        System.out.println("Core Course: " + name);
    }
}

// Represents an elective course
public static class ElectiveCourse_ implements _Course {
    private String name;

    // Constructor to initialize the course name
    public ElectiveCourse_(String name) {
        this.name = name;
    }

    // Displays course details
    @Override
    public void Info() {
        System.out.println("Elective Course: " + name);
    }
}

// Represents a lab course
public static class  LabCourse_ implements _Course {
    private String name;

    // Constructor to initialize the course name
    public LabCourse_(String name) {
        this.name = name;
    }

    // Displays course details
    @Override
    public void Info() {
        System.out.println("Lab Course: " + name);
    }
}

// Proxy class to manage course creation and caching
public static class CourseProxy {
    private Map<String, _Course> coursesCache = new HashMap<>(); // Cache to store course objects

    // Method to create or fetch a course from the cache
    public _Course getCourse(String type, String name) {
        // Check if the course type is already in the cache
        if (!coursesCache.containsKey(type)) {
            // Create the appropriate course based on the type
            switch (type.toLowerCase()) {
                case "core":
                    coursesCache.put(type, new CoreCourse_(name)); // Add core course to the cache
                    break;
                case "elective":
                    coursesCache.put(type, new ElectiveCourse_(name)); // Add elective course to the cache
                    break;
                case "lab":
                    coursesCache.put(type, new LabCourse_(name)); // Add lab course to the cache
                    break;
                default:
                    System.out.println("Invalid course type: " + type); // Handle unknown course types
                    return null;
            }
        }
        return coursesCache.get(type); // Return the course from the cache
    }
}

 public static void main(String[] args) {
        // Create instances using the factory
        StudentTypes graduate = StudentTypesFactory.createStudent("Graduate");
        StudentTypes undergraduate = StudentTypesFactory.createStudent("Undergraduate");
        StudentTypes partTime = StudentTypesFactory.createStudent("Part-Time");

        // Call the Type method on each instance
        graduate.Type();
        undergraduate.Type();
        partTime.Type();
        //\\
        CourseTypes CoreCoursee = CourseTypesFactory.createCourse("Core");
        CourseTypes ElectiveCoursee = CourseTypesFactory.createCourse("Elective");
        CourseTypes LabCoursee = CourseTypesFactory.createCourse("Lab");

     
        CoreCoursee.displayType();
        ElectiveCoursee.displayType();
        LabCoursee.displayType();
       //\\
        CourseRegistration student = CourseRegistration.getinstance();
             student.enroll("21000", "CO");
             student.enroll("21001", "CS");
             student.enroll("21002", "OS , CO");
             student.printEnrollments();
       //\\
       // Get the single instance of the grade processing system
            GradeProcessing gradeSystem = GradeProcessing.getInstance();
        
             // Set grade weights
             gradeSystem.setGradeWeight("Math", 2);
             gradeSystem.setGradeWeight("Science", 1);

             // Set grades
             Map<String, Integer> grades = new HashMap<>();
             //stores the key-value pairs in an unordered fashion and provides efficient access to values via keys.
             grades.put("Math", 85);
             grades.put("Science", 90);

             // Calculate final grade
             double finalGrade = gradeSystem.calculateGrade(grades);
             System.out.println("Final Grade: " + finalGrade);

       //\\ 
        Students_ student6 = new Students_.StudentBuilder("Mohamed", 210798)
                .addCourse("Math")
                .addCourse("Physics")
                .build();

        // Printing the student details
        System.out.println(student6);
        //\\
        // Create initial course objects
        CoreCourse coreCourse = new CoreCourse("Math"); // Core course
        ElectiveCourse electiveCourse = new ElectiveCourse("History"); // Elective course
        LabCourse labCourse = new LabCourse("Physics "); // Lab course

        // Clone the courses
        Course_ clonedCore = coreCourse.clone(); // Clone the core course
        Course_ clonedElective = electiveCourse.clone(); // Clone the elective course
        Course_ clonedLab = labCourse.clone(); // Clone the lab course

        // Display information of the cloned courses
        clonedCore.displayInfo();    // Output: Core Course: Mathematics
        clonedElective.displayInfo(); // Output: Elective Course: History
        clonedLab.displayInfo();     // Output: Lab Course: Physics Lab
        //\\
         CourseProxy proxy = new CourseProxy();

        // Create courses using the proxy
        _Course coreCourse_ = proxy.getCourse("core", "Math");
        _Course electiveCourse_ = proxy.getCourse("elective", "History");
        _Course labCourse_ = proxy.getCourse("lab", "Physics ");

        // Display information about the courses
        if (coreCourse_ != null) coreCourse_.Info();        
        if (electiveCourse_ != null) electiveCourse_.Info();
        if (labCourse_ != null) labCourse_.Info();           

        // Try creating a course with an invalid type
        _Course unknownCourse = proxy.getCourse("unknown", "Unknown Course"); // Output: Invalid course type: unknown
    }
}

   



