create table students (
student_id   int ,courses   varchar , grade  int,weight  int ,student_type  varchar ,course_type  varchar , student_name  varchar
)
 insert into students(student_id,student_type) values ('210719','Graduate');
 insert into students(student_id,student_type,courses) values ('21000','Undergraduate','Co');
 insert into students(student_id,student_type,courses)  values ('21001','Part-Time','Cs');
 insert into students(student_id,courses)  values ('21002','OS,Co');
 insert into students(student_name,courses,course_type,weight,grade)  values ('mohamed','Math','Core','2','85');
 insert into students(courses,course_type)  values ('History','Elective');
 insert into students(courses,course_type)  values ('Physics','Lab');
 insert into students(courses,grade,weight)  values ('Science','90','1');
 

 select*from students;

